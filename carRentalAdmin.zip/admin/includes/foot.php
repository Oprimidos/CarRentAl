
 <script src="assets/vendors/js/vendor.bundle.base.js"></script>

 <script src="assets/vendors/chart.js/Chart.min.js"></script>

 <script src="assets/js/off-canvas.js"></script>
 <script src="assets/js/hoverable-collapse.js"></script>
 <script src="assets/js/misc.js"></script>

 <script src="assets/js/todolist.js"></script>
 <script src="assets/js/file-upload.js"></script>


 <script src="vendor2/datatables/jquery.dataTables.min.js"></script>
 <script src="vendor2/datatables/dataTables.bootstrap4.min.js"></script>

 <script src="assets2/js/jquery.cslider.js"></script>
 <script src="assets2/js/jquery.isotope.min.js"></script>
 <script src="assets2/js/fancybox/jquery.fancybox.pack.js" type="text/javascript"></script>
 <script src="assets2/js/custom.js"></script>
 

<script>
    $(document).ready(function () {
      $('#dataTable').DataTable(); 
      $('#dataTableHover').DataTable(); 
    });
  </script>